package com.example.redis.service;

import io.lettuce.core.cluster.api.StatefulRedisClusterConnection;
import io.lettuce.core.cluster.api.sync.RedisAdvancedClusterCommands;
import org.springframework.stereotype.Service;

@Service
public class RedisService {

    private final RedisAdvancedClusterCommands<String, String> commands;

    public RedisService(StatefulRedisClusterConnection<String, String> connection) {
        this.commands = connection.sync();
    }

    public void setValue(String key, String value) {
        commands.set(key, value);
    }

    public String getValue(String key) {
        return commands.get(key);
    }
}
