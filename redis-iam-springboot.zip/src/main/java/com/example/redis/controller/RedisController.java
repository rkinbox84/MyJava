package com.example.redis.controller;

import com.example.redis.service.RedisService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/redis")
public class RedisController {

    private final RedisService redisService;

    public RedisController(RedisService redisService) {
        this.redisService = redisService;
    }

    @PostMapping("/set")
    public ResponseEntity<String> setKey(
            @RequestParam String key,
            @RequestParam String value
    ) {
        redisService.setValue(key, value);
        return ResponseEntity.ok("Set key '" + key + "' successfully.");
    }

    @GetMapping("/get")
    public ResponseEntity<String> getKey(@RequestParam String key) {
        String value = redisService.getValue(key);
        if (value != null) {
            return ResponseEntity.ok(value);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
