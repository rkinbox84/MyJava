package com.example.redis.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.elasticache.ElastiCacheUtilitiesClient;
import software.amazon.awssdk.services.elasticache.model.AuthToken;

@Component
public class RedisIamTokenProvider {

    private final String host;
    private final int port;
    private final String userId;
    private final String replicationGroupId;
    private final Region region;

    public RedisIamTokenProvider(
            @Value("${aws.elasticache.host}") String host,
            @Value("${aws.elasticache.port}") int port,
            @Value("${aws.elasticache.user-id}") String userId,
            @Value("${aws.elasticache.replication-group-id}") String replicationGroupId,
            @Value("${aws.region}") String region
    ) {
        this.host = host;
        this.port = port;
        this.userId = userId;
        this.replicationGroupId = replicationGroupId;
        this.region = Region.of(region);
    }

    public String generateToken() {
        ElastiCacheUtilitiesClient client = ElastiCacheUtilitiesClient.builder()
                .region(region)
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();

        AuthToken token = client.authToken(b -> b
                .endpoint(host)
                .port(port)
                .userId(userId)
                .replicationGroupId(replicationGroupId)
        );

        return token.token();
    }
}
