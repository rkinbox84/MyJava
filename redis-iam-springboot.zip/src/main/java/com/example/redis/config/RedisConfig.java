package com.example.redis.config;

import io.lettuce.core.RedisURI;
import io.lettuce.core.cluster.RedisClusterClient;
import io.lettuce.core.cluster.api.StatefulRedisClusterConnection;
import io.lettuce.core.resource.ClientResources;
import io.lettuce.core.resource.DefaultClientResources;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;
import java.util.Collections;

@Configuration
public class RedisConfig {

    @Value("${aws.elasticache.host}")
    private String redisHost;

    @Value("${aws.elasticache.port}")
    private int redisPort;

    private final IamTokenRefresher tokenRefresher;

    public RedisConfig(IamTokenRefresher tokenRefresher) {
        this.tokenRefresher = tokenRefresher;
    }

    @Bean(destroyMethod = "shutdown")
    public ClientResources clientResources() {
        return DefaultClientResources.create();
    }

    @Bean(destroyMethod = "close")
    public StatefulRedisClusterConnection<String, String> redisConnection(ClientResources clientResources) {
        RedisURI redisURI = RedisURI.builder()
                .withHost(redisHost)
                .withPort(redisPort)
                .withSsl(true)
                .withVerifyPeer(false)
                .withTimeout(Duration.ofSeconds(5))
                .withPassword(() -> tokenRefresher.getToken().toCharArray())
                .build();

        RedisClusterClient client = RedisClusterClient.create(clientResources, Collections.singleton(redisURI));
        return client.connect();
    }
}
