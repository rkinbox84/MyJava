package com.example.redis.config;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicReference;

@Component
public class IamTokenRefresher {

    private final RedisIamTokenProvider tokenProvider;
    private final AtomicReference<String> currentToken = new AtomicReference<>();

    public IamTokenRefresher(RedisIamTokenProvider tokenProvider) {
        this.tokenProvider = tokenProvider;
    }

    @PostConstruct
    public void init() {
        refreshToken();
    }

    @Scheduled(fixedRateString = "#{${aws.elasticache.token-refresh-interval:10} * 60 * 1000}")
    public void refreshToken() {
        String token = tokenProvider.generateToken();
        currentToken.set(token);
        System.out.println("[IAM] Refreshed token");
    }

    public String getToken() {
        return currentToken.get();
    }
}
